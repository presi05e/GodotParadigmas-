# Taller 1 - Refactorizacion con POO

Proyecto realizado en Godot 4.7 con C#.

## Controles

- Flechas: mover al vendedor.
- X: interactuar con el NPC cercano.
- Z: mostrar u ocultar el historial de transacciones.

## Comportamiento

- Lancer compra un tronco por 1 moneda.
- Monk compra un tronco por 4 monedas.
- Goblin roba 1 moneda, solo si el vendedor tiene monedas.
- El historial guarda una transaccion por NPC y aumenta su contador en cada nueva interaccion.

## Estructura

- `Characters/`: vendedor, NPCs e interfaces.
- `Systems/`: clases de transacciones.
- `docs/diagrama-clases.drawio`: diagrama UML editable en Draw.io.
- `docs/CAMBIOS_LINEA_POR_LINEA.md`: explicacion detallada de los cambios realizados.

Abre `project.godot` con Godot 4.7 .NET y ejecuta la escena principal con F6 o F5.

## Subir a GitHub

Desde la carpeta raiz del proyecto, ejecuta estos comandos una vez que hayas probado el juego:

```powershell
git add .
git commit -m "Entrega taller 1 de paradigmas"
git branch -M main
git remote add origin https://github.com/presi05e/GodotParadigmas-.git
git push -u origin main
```

Si `origin` ya existe, no ejecutes de nuevo la linea `git remote add origin`.
