public class Theft : Transaction
{
    public override string Type => "Robo";

    public Theft(NPC npc) : base(npc)
    {
    }
}
