public abstract class Transaction
{
    public NPC Npc { get; private set; }
    public int TotalCounts { get; private set; }
    public abstract string Type { get; }

    protected Transaction(NPC npc)
    {
        Npc = npc;
    }

    public void IncreaseTotalCounts()
    {
        TotalCounts++;
    }

    public string GetHistoryLine()
    {
        return Npc.Name + " - " + Type + ": " + TotalCounts;
    }
}
