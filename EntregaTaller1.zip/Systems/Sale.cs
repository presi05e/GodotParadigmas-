public class Sale : Transaction
{
    public override string Type => "Venta";

    public Sale(NPC npc) : base(npc)
    {
    }
}
