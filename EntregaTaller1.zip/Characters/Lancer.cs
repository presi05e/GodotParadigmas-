using Godot;
public partial class Lancer : NPC, IBuyer
{
    private const int PricePerWood = 1;

    public int Price => PricePerWood;

    public void Buy(Seller seller)
    {
        seller.SellWoodTo(this, Price);
    }
}
