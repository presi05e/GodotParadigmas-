using Godot;
using System.Collections.Generic;

public partial class Seller : CharacterBody2D
{
	private const int InitialWoodCounts = 20;
	private const float MovementSpeed = 100.0f;

	private AnimatedSprite2D _animator;
	private TextureRect _xIndicator;
	private Label _woodIndicator;
	private Label _coinIndicator;
	private Panel _historyPanel;
	private Label _historyLabel;
	private Node2D _npc;
	private readonly List<Transaction> _transactions = new List<Transaction>();

	public int WoodCounts { get; private set; } = InitialWoodCounts;
	public int CoinCounts { get; private set; } = 0;

	public override void _Ready()
	{
		_animator = GetNode<AnimatedSprite2D>("Animator");
		_animator.Play("default");

		_xIndicator = GetNode<TextureRect>("Screen/XIndicator");
		_xIndicator.Visible = false;

		_woodIndicator = GetNode<Label>("Screen/WoodIndicator/Label");
		_coinIndicator = GetNode<Label>("Screen/CoinIndicator/Label");
		_historyPanel = GetNode<Panel>("Screen/HistoryPanel");
		_historyLabel = GetNode<Label>("Screen/HistoryPanel/HistoryLabel");

		_historyPanel.Visible = false;
		UpdateIndicators();
	}

	public override void _Process(double delta)
	{
		UpdateMovement();
		MoveAndSlide();
		HandleInteraction();
		HandleHistoryInput();
	}

	private void UpdateMovement()
	{
		Vector2 movement = Input.GetVector("move_left", "move_right", "move_up", "move_down");
		Velocity = movement * MovementSpeed;

		if (Velocity == Vector2.Zero)
		{
			_animator.Play("default");
			return;
		}

		_animator.Play("run");
		_animator.FlipH = Velocity.X < 0 || Velocity.Y > 0;
	}

	private void HandleInteraction()
	{
		if (_xIndicator.Visible && Input.IsActionJustPressed("sell"))
		{
			InteractWithCurrentNpc();
		}
	}

	private void HandleHistoryInput()
	{
		if (Input.IsActionJustPressed("show_resume"))
		{
			ToggleHistory();
		}
	}

	private void InteractWithCurrentNpc()
	{
		if (_npc is IBuyer buyer)
		{
			buyer.Buy(this);
		}

		if (_npc is IThief thief)
		{
			thief.Steal(this);
		}
	}

	private void _InteractWithNPC(Node2D body)
	{
		if (body == this) return;

		_xIndicator.Visible = true;

		_npc = body;
	}

	private void _ExitNPC(Node2D body)
	{
		_xIndicator.Visible = false;
		_npc = null;
	}

	public void SellWoodTo(NPC buyer, int price)
	{
		if (WoodCounts <= 0) return;

		WoodCounts--;
		CoinCounts += price;
		RegisterTransaction(new Sale(buyer));
		UpdateIndicators();
	}

	public void StealCoins(NPC thief, int quantity)
	{
		if (CoinCounts < quantity) return;

		CoinCounts -= quantity;
		RegisterTransaction(new Theft(thief));
		UpdateIndicators();
	}

	private void RegisterTransaction(Transaction newTransaction)
	{
		Transaction transaction = FindTransaction(newTransaction.Npc);

		if (transaction == null)
		{
			transaction = newTransaction;
			_transactions.Add(transaction);
		}

		transaction.IncreaseTotalCounts();

		if (_historyPanel.Visible)
		{
			_historyLabel.Text = CreateHistoryText();
		}
	}

	private Transaction FindTransaction(NPC npc)
	{
		foreach (Transaction transaction in _transactions)
		{
			if (transaction.Npc == npc)
			{
				return transaction;
			}
		}

		return null;
	}

	private void ToggleHistory()
	{
		_historyPanel.Visible = !_historyPanel.Visible;

		if (_historyPanel.Visible)
		{
			_historyLabel.Text = CreateHistoryText();
		}
	}

	private string CreateHistoryText()
	{
		if (_transactions.Count == 0)
		{
			return "Historial vacio.";
		}

		string history = "HISTORIAL DE TRANSACCIONES\n";

		foreach (Transaction transaction in _transactions)
		{
			history += transaction.GetHistoryLine() + "\n";
		}

		return history;
	}

	private void UpdateIndicators()
	{
		_woodIndicator.Text = WoodCounts.ToString();
		_coinIndicator.Text = CoinCounts.ToString();
	}
}
