using Godot;

// Clase base para todos los personajes no controlados por el jugador.
public partial class NPC : StaticBody2D
{
    protected AnimatedSprite2D Animator;

    public override void _Ready()
    {
        Animator = GetNode<AnimatedSprite2D>("Animator");
        Animator.Play("default");
    }
}
