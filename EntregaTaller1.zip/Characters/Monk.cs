using Godot;

public partial class Monk : NPC, IBuyer
{
    private const int PricePerWood = 4;

    public int Price => PricePerWood;

    public void Buy(Seller seller)
    {
        seller.SellWoodTo(this, Price);
    }
}
