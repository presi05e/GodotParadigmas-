// Contrato para los NPC que compran madera al vendedor.
public interface IBuyer
{
    int Price { get; }

    void Buy(Seller seller);
}
