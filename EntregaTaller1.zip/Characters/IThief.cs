// Contrato para los NPC que pueden robar monedas al vendedor.
public interface IThief
{
    void Steal(Seller seller);
}
