using Godot;

public partial class Goblin : NPC, IThief
{
    private const int CoinsToSteal = 1;

    public void Steal(Seller seller)
    {
        seller.StealCoins(this, CoinsToSteal);
    }
}
