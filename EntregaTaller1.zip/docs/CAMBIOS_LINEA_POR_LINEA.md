# Cambios linea por linea - Taller 1

Este documento compara la base entregada por el profesor con la version final. Las lineas indicadas corresponden a la version final de cada archivo.

## Resumen de lo nuevo, lo modificado y lo conservado

| Estado | Archivos | Motivo |
| --- | --- | --- |
| Nuevos | `NPC.cs`, `IBuyer.cs`, `IThief.cs`, `Transaction.cs`, `Sale.cs`, `Theft.cs` | Aplicar herencia, interfaces y transacciones. |
| Modificados | `Seller.cs`, `Lancer.cs`, `Monk.cs`, `Goblin.cs`, `world.tscn`, `seller.tscn`, `README.md` | Implementar los comportamientos solicitados y el HUD. |
| Conservados | `project.godot`, `SellerGame.csproj`, las escenas individuales de Lancer, Monk y Goblin, `Assets/` y el paquete `Tiny Swords (Free Pack)/` | Mantienen configuracion, controles, sprites y animaciones originales. |

## Archivos nuevos

### `Characters/NPC.cs`

- Linea 1: importa `Godot` para usar `StaticBody2D` y `AnimatedSprite2D`.
- Linea 3: documenta que la clase representa a un NPC.
- Linea 4: declara `NPC` como clase base que hereda de `StaticBody2D`.
- Linea 6: declara `Animator` como `protected`; las clases hijas pueden usarlo, pero otras clases no.
- Lineas 8-12: `_Ready()` busca el nodo hijo `Animator` y reproduce la animacion `default`.
- Linea 13: cierra la clase.

Este archivo reemplaza el bloque repetido que estaba en Lancer, Monk y Goblin. No cambia los sprites ni las escenas de esos personajes.

### `Characters/IBuyer.cs`

- Linea 1: comentario que describe el contrato.
- Linea 2: declara la interfaz `IBuyer`.
- Linea 4: exige la propiedad de solo lectura `Price`.
- Linea 6: exige el metodo `Buy(Seller seller)`.

Una interfaz no tiene logica; solo define lo que debe poder hacer un comprador.

### `Characters/IThief.cs`

- Linea 1: comentario del contrato de robo.
- Linea 2: declara la interfaz `IThief`.
- Linea 4: exige el metodo `Steal(Seller seller)`.

### `Systems/Transaction.cs`

- Linea 1: declara `Transaction` como abstracta. No se crea una transaccion generica; se crean ventas o robos.
- Linea 3: guarda una referencia al `NPC` involucrado.
- Linea 4: guarda la cantidad acumulada de interacciones con ese NPC.
- Linea 5: obliga a las clases hijas a indicar el tipo de transaccion.
- Lineas 7-10: constructor que recibe y conserva el NPC.
- Lineas 12-15: aumenta el contador acumulado.
- Lineas 17-20: construye una linea legible para el historial: nombre, tipo y total.

### `Systems/Sale.cs`

- Linea 1: `Sale` hereda de `Transaction`.
- Linea 3: identifica la transaccion como `Venta`.
- Lineas 5-7: envia el NPC al constructor de la clase base.

### `Systems/Theft.cs`

- Linea 1: `Theft` hereda de `Transaction`.
- Linea 3: identifica la transaccion como `Robo`.
- Lineas 5-7: envia el NPC al constructor de la clase base.

## Archivos de personajes modificados

### `Characters/Lancer.cs`

- Linea 2: cambio de herencia. Antes heredaba directamente de `StaticBody2D`; ahora hereda de `NPC` e implementa `IBuyer`.
- Linea 4: reemplaza el numero magico del precio con la constante `PricePerWood = 1`.
- Linea 6: implementa la propiedad requerida por `IBuyer`.
- Lineas 8-11: `Buy` delega la venta a `Seller`. Lancer no modifica contadores directamente.

Se eliminaron el campo de animacion, `_Ready()` y `_Process()` vacio porque ahora pertenecen a `NPC`.

### `Characters/Monk.cs`

- Linea 3: Monk hereda de `NPC` e implementa `IBuyer`.
- Linea 5: define su precio como 4 monedas por tronco.
- Linea 7: expone ese precio mediante `Price`.
- Lineas 9-12: llama a `Seller.SellWoodTo(this, Price)`.

No fue necesario agregar una condicion especial en `Seller` para Monk. Esto demuestra polimorfismo: ambos compradores cumplen `IBuyer`.

### `Characters/Goblin.cs`

- Linea 3: Goblin hereda de `NPC` e implementa `IThief`.
- Linea 5: reemplaza el numero magico del robo por `CoinsToSteal = 1`.
- Lineas 7-10: solicita a Seller que aplique el robo. Seller valida el saldo.

## `Characters/Seller.cs` - cambios detallados

### Declaraciones y encapsulamiento

- Linea 2: se agrega `System.Collections.Generic` para usar `List<Transaction>`.
- Lineas 6-7: constantes para madera inicial y velocidad; eliminan numeros magicos.
- Lineas 9-15: referencias privadas a nodos del juego y HUD. Las lineas 13-14 son nuevas para el panel de historial.
- Linea 16: lista privada de transacciones. Seller la crea y controla, por eso es composicion.
- Lineas 18-19: contadores publicos solo para lectura externa; `private set` impide que otro NPC los cambie directamente.

### Inicializacion del HUD

- Lineas 21-24: obtiene e inicia la animacion del vendedor, igual que en la base.
- Lineas 26-27: conserva el indicador X, inicialmente oculto.
- Lineas 29-32: obtiene indicadores de madera, monedas y los dos nodos nuevos del historial.
- Linea 34: mantiene el historial oculto al comenzar.
- Linea 35: actualiza los contadores iniciales del HUD.

### Proceso y movimiento

- Lineas 38-44: `_Process()` ahora solo orquesta: movimiento, fisica, interaccion e historial.
- Lineas 46-59: `UpdateMovement()` conserva las flechas, la velocidad y las animaciones originales, pero separa esa responsabilidad de `_Process()`.
- Lineas 61-67: `HandleInteraction()` verifica X e invoca el metodo de interaccion.
- Lineas 69-75: `HandleHistoryInput()` detecta Z e invoca el metodo que alterna el panel.

### Polimorfismo e interaccion

- Lineas 77-88: `InteractWithCurrentNpc()` usa `IBuyer` e `IThief`. No contiene `if (_npc is Lancer)`, `if (_npc is Monk)` ni `if (_npc is Goblin)`.
- Lineas 90-97: conserva la senal de entrada al area, muestra X y guarda el NPC cercano.
- Lineas 99-103: conserva la senal de salida del area, oculta X y elimina la referencia al NPC.

### Venta, robo y transacciones

- Lineas 105-113: `SellWoodTo()` valida madera, descuenta un tronco, suma el precio recibido, registra una `Sale` y actualiza el HUD.
- Lineas 115-122: `StealCoins()` valida que existan monedas suficientes. Si hay 0, termina sin modificar el contador; si hay saldo, resta, registra un `Theft` y actualiza el HUD.
- Lineas 124-140: `RegisterTransaction()` busca una transaccion existente del mismo NPC. Si no existe crea una; siempre aumenta el contador. Esta es la regla de una transaccion por NPC.
- Lineas 142-153: `FindTransaction()` recorre la lista y compara referencias a NPC, no nombres ni cadenas de texto.

### Historial visual

- Lineas 155-163: `ToggleHistory()` muestra u oculta el panel con Z y actualiza el texto al abrirlo.
- Lineas 165-180: `CreateHistoryText()` devuelve el mensaje vacio o cada registro generado por `Transaction`.
- Lineas 182-186: `UpdateIndicators()` centraliza la actualizacion visual de madera y monedas.

## Escenas modificadas

### `world.tscn`

- Linea 6: agrega la escena `monk.tscn` como recurso externo.
- Lineas 7-8: agregan texturas del paquete Tiny Swords para el fondo.
- Lineas 12-15: crean `WaterBackground`, sin colision y con capa `z_index = -2`, por detras de los personajes.
- Lineas 17-20: crean `GrassIsland`, tambien sin colision y en la capa visual inmediatamente superior al agua.
- Lineas 28-29: instancian Monk y le asignan una posicion en el mapa.

Lancer, Goblin, Seller y Camera2D se conservan. Solo se agregaron nodos nuevos.

### `Characters/seller.tscn`

- Linea 191: cambia el texto de X de `vender` a `interactuar`, porque ahora X sirve tanto para vender como para sufrir un robo.
- Linea 207: cambia el texto de Z para indicar que abre el historial.
- Lineas 209-213: agregan el panel visual `HistoryPanel`.
- Lineas 215-221: agregan `HistoryLabel`, donde Seller escribe el historial.
- Lineas 223-224: las conexiones originales de entrada y salida del Area2D se conservan sin cambios.

## Archivos conservados

- `project.godot`: conserva los controles de flechas, X y Z, la escena principal y la configuracion de Godot 4.7.
- `SellerGame.csproj` y `SellerGame.sln`: conservan la configuracion C# y .NET del proyecto.
- `Characters/lancer.tscn`, `Characters/monk.tscn` y `Characters/goblin.tscn`: conservan sus sprites, colisiones y animaciones. Sus scripts ahora usan la nueva jerarquia, pero las escenas no necesitaron cambios.
- `Assets/` y `Tiny Swords (Free Pack)/`: son recursos graficos; no se modificaron. Solo se referenciaron dos imagenes del paquete para el fondo.

## UML

`diagrama-clases.drawio` es el UML final editable. Incluye las clases nuevas, atributos, metodos, herencia de `NPC`, implementacion de interfaces, herencia de transacciones y la composicion `Seller -> List<Transaction>`.
