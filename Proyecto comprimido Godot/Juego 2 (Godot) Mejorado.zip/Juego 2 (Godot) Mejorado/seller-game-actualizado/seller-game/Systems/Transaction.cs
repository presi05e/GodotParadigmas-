using Godot;

/// <summary>
/// Representa un único registro de interacción entre el Vendedor y un NPC.
/// Es una clase inmutable: una vez creada, sus datos no cambian.
/// Esto evita que otra parte del código modifique el histórico "por accidente".
/// </summary>
public sealed class Transaction
{
    public string SellerName { get; }
    public string BuyerName { get; }
    public string ItemName { get; }
    public int Quantity { get; }
    public int Price { get; }
    public string CurrencyName { get; }

    public Transaction(
        string sellerName,
        string buyerName,
        string itemName,
        int quantity,
        int price,
        string currencyName = "moneda")
    {
        SellerName = sellerName;
        BuyerName = buyerName;
        ItemName = itemName;
        Quantity = quantity;
        Price = price;
        CurrencyName = currencyName;
    }

    /// <summary>
    /// Da formato al registro tal como debe verse en pantalla.
    /// Ejemplo: "Vendedor vendió (1) tronco a Lancero por (1) moneda"
    /// </summary>
    public override string ToString()
    {
        string currency = Price == 1 ? CurrencyName : CurrencyName + "s";
        return $"{SellerName} vendió ({Quantity}) {ItemName} a {BuyerName} por ({Price}) {currency}";
    }
}
