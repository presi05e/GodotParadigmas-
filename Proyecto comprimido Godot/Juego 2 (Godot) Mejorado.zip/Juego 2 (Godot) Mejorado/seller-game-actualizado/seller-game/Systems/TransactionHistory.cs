using Godot;
using System.Collections.Generic;

/// <summary>
/// Guarda, en un único lugar accesible desde cualquier script, todas las
/// interacciones que ocurren entre el Vendedor y los NPCs.
///
/// Se registra como Autoload (Singleton) en Project Settings > Autoload,
/// por eso hereda de Node: Godot lo crea una sola vez y vive durante
/// toda la partida, sin importar qué escena esté activa.
/// </summary>
public partial class TransactionHistory : Node
{
    // Punto de acceso global: desde cualquier script se llama
    // TransactionHistory.Instance.Register(...)
    public static TransactionHistory Instance { get; private set; }

    private readonly List<Transaction> _transactions = new();

    // Colección de solo lectura hacia afuera: nadie puede añadir o borrar
    // elementos directamente, solo a través del método Register.
    public IReadOnlyList<Transaction> Transactions => _transactions;

    // Señal (evento) que se dispara cada vez que se agrega una transacción.
    // Cualquier nodo puede "suscribirse" para enterarse automáticamente,
    // sin necesidad de estar preguntando todo el tiempo si algo cambió.
    [Signal]
    public delegate void HistoryUpdatedEventHandler();

    public override void _Ready()
    {
        Instance = this;
    }

    public void Register(Transaction transaction)
    {
        _transactions.Add(transaction);
        EmitSignal(SignalName.HistoryUpdated);
    }

    public void Register(
        string sellerName,
        string buyerName,
        string itemName,
        int quantity,
        int price,
        string currencyName = "moneda")
    {
        Register(new Transaction(sellerName, buyerName, itemName, quantity, price, currencyName));
    }

    /// <summary>
    /// Devuelve todo el histórico ya formateado como texto, listo para
    /// mostrarse en un Label o RichTextLabel. El más reciente aparece primero.
    /// </summary>
    public string GetFormattedHistory()
    {
        if (_transactions.Count == 0)
        {
            return "Aún no se registran interacciones.";
        }

        var lines = new List<string>();
        for (int i = _transactions.Count - 1; i >= 0; i--)
        {
            int number = _transactions.Count - i;
            lines.Add($"{number}. {_transactions[i]}");
        }

        return string.Join("\n", lines);
    }
}
