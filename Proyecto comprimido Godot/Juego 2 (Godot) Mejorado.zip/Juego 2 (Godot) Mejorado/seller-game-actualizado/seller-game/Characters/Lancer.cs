using Godot;
using System;

public partial class Lancer : StaticBody2D
{
    // Nombre "amigable" que se muestra en el histórico de transacciones.
    // Se puede editar desde el inspector de Godot sin tocar código.
    [Export] public string DisplayName { get; set; } = "Lancero";

    private AnimatedSprite2D _animator;

    public override void _Ready()
	{
        _animator = GetNode<AnimatedSprite2D>("Animator");
        _animator.Play("default");
    }

	public override void _Process(double delta)
	{
	}

    public void Buy(Seller seller)
    {
        if (seller.WoodCounts <= 0) return;

        const string item = "tronco";
        const int quantity = 1;
        const int price = 1;

        seller.DiscountWood();
        seller.IncreaseCoin();

        TransactionHistory.Instance?.Register(
            sellerName: seller.DisplayName,
            buyerName: DisplayName,
            itemName: item,
            quantity: quantity,
            price: price);
    }
}
